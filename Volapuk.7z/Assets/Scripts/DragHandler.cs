﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;
using UnityEngine.UI;
public class DragHandler : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public  GameObject itemBeingDragged;
    //test
    public Text rep;

    Vector3 startPosition;

    //inside class
    Vector2 firstPressPos;
    Vector2 secondPressPos;
    Vector2 currentSwipe;

    
   
    public void OnBeginDrag(PointerEventData eventData)
    {
        itemBeingDragged = this.gameObject;
        startPosition = transform.position;
        //save began touch 2d point
        firstPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    }

    public void OnDrag(PointerEventData eventData)
    {
        transform.position = Input.mousePosition;

      
       
        //save ended touch 2d point
        secondPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);

        //create vector from the two points
        currentSwipe = new Vector2(secondPressPos.x - firstPressPos.x, secondPressPos.y - firstPressPos.y);

        //normalize the 2d vector
        currentSwipe.Normalize();


        //swipe down
        if (currentSwipe.y < 0 && currentSwipe.x > -0.5f && currentSwipe.x < 0.5f)
        {
            rep.text = "Je passe";


        }
        //swipe left
        if (currentSwipe.x < 0 && currentSwipe.y > -0.5f && currentSwipe.y < 0.5f)
        {


            rep.text = "Non";


        }
        //swipe right
        if (currentSwipe.x > 0 && currentSwipe.y > -0.5f && currentSwipe.y < 0.5f)
        {

            rep.text = "Oui";

        }
    }

    /*public void OnEndDrag(PointerEventData eventData)
    {
        itemBeingDragged = null;
        transform.position = startPosition;
        //save ended touch 2d point
        secondPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);

        //create vector from the two points
        currentSwipe = new Vector2(secondPressPos.x - firstPressPos.x, secondPressPos.y - firstPressPos.y);

        //normalize the 2d vector
        currentSwipe.Normalize();

        //swipe down
        if (currentSwipe.y < 0 && currentSwipe.x > -0.5f && currentSwipe.x < 0.5f)
        {
          
            QuizzLoader.instance.LoadNextQuestion();
        }
        //swipe left
        if (currentSwipe.x < 0 && currentSwipe.y > -0.5f && currentSwipe.y < 0.5f)
        {

            QuizzLoader.instance.CompleteQuestion();
       
    
            if (!QuizzLoader.instance.CurrentQuizzElt.isTrue)
            {
        
                QuizzLoader.instance.correctAnswer++;
            }
            else
            {
              
                QuizzLoader.instance.wrongAnswer++;
            }
            QuizzLoader.instance.NbReplied++;
            QuizzLoader.instance.LoadNextQuestion();
        


        }
        //swipe right
        if (currentSwipe.x > 0 && currentSwipe.y > -0.5f && currentSwipe.y < 0.5f)
        {
            QuizzLoader.instance.CompleteQuestion();
 
            if (QuizzLoader.instance.CurrentQuizzElt.isTrue)
            {
                  QuizzLoader.instance.correctAnswer++;
            }

            else
            {
                QuizzLoader.instance.wrongAnswer++;

            }
            QuizzLoader.instance.NbReplied++;
            QuizzLoader.instance.LoadNextQuestion();
          

        }
    }*/


    public void OnEndDrag(PointerEventData eventData)
    {

        //save ended touch 2d point
        secondPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);

        //create vector from the two points
        currentSwipe = new Vector2(secondPressPos.x - firstPressPos.x, secondPressPos.y - firstPressPos.y);

        //normalize the 2d vector
        currentSwipe.Normalize();

        //swipe down
        if (currentSwipe.y < 0 && currentSwipe.x > -0.5f && currentSwipe.x < 0.5f)
        {
            rep.text = "je passe la question ";


        }
        //swipe left
        else if (currentSwipe.x < 0 && currentSwipe.y > -0.5f && currentSwipe.y < 0.5f)
        {


            rep.text = "reponse = non";


        }
        //swipe right
        else if (currentSwipe.x > 0 && currentSwipe.y > -0.5f && currentSwipe.y < 0.5f)
        {

            rep.text = "reponse = Oui";

        }
        else
        {
            transform.position = startPosition;
        }
        itemBeingDragged = null;
       
      
    }
}
