﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class QuizzLoader : MonoBehaviour {

    Question allquizz = new Question();
    string jsonString;
    public int questionIndex;
    int currentIndex;
    public static QuizzLoader instance;
    private QuizElt currentQuizzElt = new QuizElt();

    public Text questionText;
    public Text score;

    public int maxScore;
    public int correctAnswer;
    public int wrongAnswer;
    public EndGamePanel panelEndgame;
    private int nbReplied;
    public TimerUI timer;

    public int CurrentIndex
    {
        get
        {
            return currentIndex;
        }

        set
        {
            currentIndex = value;
            CurrentQuizzElt = allquizz.question[currentIndex];
            questionText.text = allquizz.question[currentIndex].question + "\n" + allquizz.question[currentIndex].response;
        }
    }

    public QuizElt CurrentQuizzElt
    {
        get
        {
            return currentQuizzElt;
        }

        private set
        {
            currentQuizzElt = value;
        }
    }

  
    public int NbReplied
    {
        get
        {
            return nbReplied;
        }

        set
        {
            nbReplied = value;
            score.text = "Bonne response " + correctAnswer + "/" + NbReplied;
        }
    }

    void Awake()
    {
        //create an instance
        instance = this;
    }

    


    void OnEnable()
    {
        LoadQuizz();
        maxScore = allquizz.question.Count;
        score.text = "Bonne response " + correctAnswer + "/" + NbReplied;
        CurrentIndex = 0;
    }

    public void LoadQuizz()
    {
        #if UNITY_EDITOR
            jsonString = System.IO.File.ReadAllText("Assets/Resources/quizz.json");

        #else
                   
            TextAsset targetFile = Resources.Load<TextAsset>("quizz");
            jsonString = targetFile.text;
                   
        #endif

        allquizz = JsonUtility.FromJson<Question>(jsonString);
    }

    public void LoadNextQuestion()
    {
        if(IsGameEnded()){
            EndGame();
            return;
        }
        if (CurrentIndex < allquizz.question.Count - 1)
            CurrentIndex++;
        else
            CurrentIndex = 0;
    }

    public void CompleteQuestion()
    {
        CurrentQuizzElt.isCompleted = true;

    }

   private bool IsGameEnded()
    {
        for ( int i =0; i< allquizz.question.Count; i++)
        {
            if (!allquizz.question[i].isCompleted)
                return false;
        }
            return true;
    }

    public void EndGame()
    {
        questionText.text = "";
        score.text = "";
        panelEndgame.gameObject.SetActive(true);
        panelEndgame.SetScore(correctAnswer, wrongAnswer, maxScore, NbReplied);
        timer.gameObject.SetActive(false);
    }

}
