﻿using UnityEngine;
using UnityEngine.UI;

public class EndGamePanel : MonoBehaviour {

    public Text correctAnswer;
    public Text wrongAnswer;
    public Text total;
    public Text answeredQuestion;

    public void SetScore(int _correctAnswer, int _WrongAnswer, int _maxScore, int _answeredQuestion)
    {
        correctAnswer.text = "Réponse correcte : " + _correctAnswer;
        wrongAnswer.text = "Réponse incorrecte : " + _WrongAnswer;
        answeredQuestion.text = "Zappé  :"+ (_maxScore - _answeredQuestion);
        total.text = "Score : " + _correctAnswer+ "/"+ _maxScore;

    }
}
