﻿using System;
using System.Collections.Generic;


[Serializable]

public class Quizzdata  {
    public List<Question> quizz;
}
