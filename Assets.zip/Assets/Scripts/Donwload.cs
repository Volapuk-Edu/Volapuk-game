﻿using UnityEngine;
using System.Collections;
using System;

public class Donwload : MonoBehaviour {

    //string URLBase = "https://doc-00-2g-docs.googleusercontent.com/docs/securesc/ha0ro937gcuc7l7deffksulhg5h7mbp1/rlk10mejbh7n6dim1n8ii50j30fajun4/1471874400000/05848131233573774337/*/0Bwz7eDsM_XkLdkNuazhad081a3M?e=download";//"http://192.168.10.7/";

    string URLBase = "https://raw.githubusercontent.com/amboara/quizzData/master/quizz.json";
    string textData;

    void OnEnable()
    {
        StartCoroutine(CheckUpdate());
    }

    private IEnumerator CheckUpdate()
    {
        // download version.xml file on server to check if there is update or no
        using (WWW www = new WWW(URLBase ))
        {
            yield return www;
            if (www.error != null)
            {
                throw new System.Exception("WWW download had an error:" + www.error);
            }
         
            textData = www.text;
            print(textData);


        } // memory is freed from the web stream (www.Dispose() gets called implicitly)
    }
}
