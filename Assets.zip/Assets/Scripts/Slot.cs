﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;

public enum State { TrueRep, FalseRep, Next }
public class Slot : MonoBehaviour, IDropHandler {

    public   State mystate;
  

    public void OnDrop(PointerEventData eventData)
    {
        //print("called");


        /*switch (mystate)
        {
            case State.TrueRep:

                if (QuizzLoader.instance.CurrentQuizzElt.isTrue)
                    print("incrementer le score des bonnes reponse");
                else
                    print("incrementer le score des mauvaises reponse");

                QuizzLoader.instance.LoadNextQuestion();

                break;
            case State.FalseRep:
                if (QuizzLoader.instance.CurrentQuizzElt.isTrue)
                    print("incrementer le score des bonnes reponse");
                else
                    print("incrementer le score des mauvaises reponse");

                QuizzLoader.instance.LoadNextQuestion();

                break;
            case State.Next:

                //do nothing
                QuizzLoader.instance.LoadNextQuestion();
                break;
        } */
    }

  
}
