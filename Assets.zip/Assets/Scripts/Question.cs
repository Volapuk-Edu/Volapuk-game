﻿using System;
using System.Collections.Generic;


[Serializable]
public class Question{
    public List<QuizElt> question ;
}

[Serializable]
public class QuizElt
{
    public string question;
    public string response;
    public string  isTrue;
    public bool isCompleted;
}
