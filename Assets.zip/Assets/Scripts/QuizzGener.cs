﻿using UnityEngine;
using System.Collections.Generic;
using System.IO;

public class QuizzGener : MonoBehaviour {

	// Use this for initialization
	void Start () {

        List<QuizElt> quizz = new List<QuizElt>();

        QuizElt q = new QuizElt();
        q.question = "Où se trouvent les glandes sudoripares d'un chien ?";
        q.response = "Sous ses pattes";    
        quizz.Add(q);

        QuizElt q1 = new QuizElt();
        q1.question = "Qui raconte les aventures de Sherlock Holmes ";
        q1.response = "Watson";
        quizz.Add(q1);

        Question quest = new Question();
      
        quest.question = quizz;

        string json = JsonUtility.ToJson(quest,true);
        Save(json, "Assets/Resources/quizz.json");

    }
	
	// Update is called once per frame
	void Update () {
	
	}

    public void Save(string json, string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.Create))
        {
            using (StreamWriter writer = new StreamWriter(fs))
            {
                writer.Write(json);
                writer.Close();
                writer.Dispose();
            }
            fs.Close();
            fs.Dispose();
        }
    }
}
